﻿-- Практическая работа № 25. Создание представлений (без вариантов)
-- Выполнил: Шангараев Амир Марселевич, группа ИС231-4, вариант 4
-- База данных: Zakaz_Project

-- Подготовка: создание БД, таблиц и данных
CREATE DATABASE Zakaz_Project;
GO
USE Zakaz_Project;
GO

CREATE TABLE dbo.Otdel (
    Namber_otdel  INT           PRIMARY KEY,
    Name_otdel    NVARCHAR(40)  NULL,
    Phone         CHAR(12)      NULL
);
CREATE TABLE dbo.[Position] (
    Kod_position   INT           PRIMARY KEY,
    Name_position  NVARCHAR(20)  NULL
);
CREATE TABLE dbo.Klient (
    Kod_klient   INT           PRIMARY KEY,
    Name_klient  NVARCHAR(50)  NULL
);
CREATE TABLE dbo.Project (
    Namber_Project  INT            PRIMARY KEY,
    Name_Project    NVARCHAR(50)   NULL,
    Price_Project   DECIMAL(8,0)   NULL,
    Kod_klient      INT            NOT NULL REFERENCES dbo.Klient(Kod_klient),
    Begin_Project   DATE           NULL,
    End_Project     DATE           NULL
);
CREATE TABLE dbo.Employee (
    Id_employee   INT            PRIMARY KEY,
    FName         NVARCHAR(20)   NULL,          -- имя
    LName         NVARCHAR(50)   NULL,          -- фамилия
    Namber_otdel  INT            NOT NULL REFERENCES dbo.Otdel(Namber_otdel),
    Kod_position  INT            NOT NULL REFERENCES dbo.[Position](Kod_position),
    Oklad         DECIMAL(7,2)   NOT NULL,
    Nadbavka      DECIMAL(6,2)   NOT NULL DEFAULT 0
);
CREATE TABLE dbo.Project_execution (
    Id_contract    INT            PRIMARY KEY,
    Id_employee    INT            NOT NULL REFERENCES dbo.Employee(Id_employee),
    Namber_Project INT            NOT NULL REFERENCES dbo.Project(Namber_Project),
    Quantity_day   INT            NULL,
    Amount         DECIMAL(7,2)   NULL
);
GO

INSERT dbo.Otdel VALUES
(1001, N'Бухгалтерия',  '843-111-0101'), (1002, N'Отдел продаж', '843-111-0102'),
(1003, N'Производство', '843-111-0103'), (1004, N'ИТ-отдел',     '843-111-0104'),
(1005, N'Отдел кадров', '843-111-0105');

INSERT dbo.[Position] VALUES (1, N'Начальник'), (2, N'Бухгалтер'), (3, N'Менеджер'),
                             (4, N'Инженер'), (5, N'Программист'), (6, N'Рабочий');

INSERT dbo.Klient VALUES (1, N'ООО Заря'), (2, N'АО Холод'), (3, N'ЗАО Таттелеком'),
                         (4, N'ООО Геракл'), (5, N'ИП Фёдоров');

INSERT dbo.Project VALUES
(1, N'Альфа',  1200000, 1, '2025-01-10', '2025-06-30'),
(2, N'Бета',    850000, 2, '2025-02-01', '2025-07-15'),
(3, N'Гамма',  2100000, 3, '2025-03-15', '2025-12-20'),
(4, N'Дельта',  640000, 1, '2025-05-01', '2025-09-30'),
(5, N'Омега',  1500000, 4, '2025-06-01', '2026-02-28');

INSERT dbo.Employee (Id_employee, FName, LName, Namber_otdel, Kod_position, Oklad, Nadbavka) VALUES
(101, N'Пётр',   N'Иванов',     1001, 1, 45000, 8000),
(102, N'Анна',   N'Петрова',    1001, 2, 38000, 5000),
(103, N'Олег',   N'Сидоров',    1002, 1, 42000, 7000),
(104, N'Мария',  N'Кузнецова',  1002, 3, 30000, 4000),
(105, N'Игорь',  N'Смирнов',    1003, 1, 40000, 6000),
(106, N'Лейла',  N'Галимова',   1003, 6, 28000, 2000),
(107, N'Ильдар', N'Назаров',    1003, 4, 36000, 3500),
(108, N'Рустам', N'Ахмадуллин', 1004, 1, 47000, 9000),
(109, N'Елена',  N'Орлова',     1004, 5, 41000, 4500),
(110, N'Игорь',  N'Сахаров',    1004, 5, 39000, 3000),
(111, N'Алина',  N'Зайцева',    1005, 3, 29000, 1500),
(112, N'Артём',  N'Волков',     1005, 2, 33000, 2500);

INSERT dbo.Project_execution (Id_contract, Id_employee, Namber_Project, Quantity_day, Amount) VALUES
(1, 101, 1, 20, 15000), (2, 102, 1, 15, 10000), (3, 104, 1, 10,  8000), (4, 107, 1, 25, 18000),
(5, 103, 2, 18, 14000), (6, 104, 2, 12,  9000), (7, 109, 2, 30, 22000),
(8, 105, 3, 40, 30000), (9, 106, 3, 35, 20000), (10, 107, 3, 28, 21000), (11, 108, 3, 22, 19000), (12, 109, 3, 25, 18500),
(13, 101, 4, 10,  7500), (14, 108, 4, 20, 16000), (15, 110, 4, 32, 23000),
(16, 103, 5, 14, 11000), (17, 105, 5, 16, 12500), (18, 109, 5, 18, 13500), (19, 110, 5, 24, 17500), (20, 106, 5, 12, 6000);
GO

-- 1. Представление SOTR_INFO: табельный номер, фамилия, имя сотрудника, название отдела, название должности и оклад.
CREATE VIEW dbo.SOTR_INFO
(Id_employee, LName, FName, Namber_otdel, Name_otdel, Kod_position, Name_position, Oklad)
AS
SELECT e.Id_employee, e.LName, e.FName, e.Namber_otdel, o.Name_otdel,
       e.Kod_position, p.Name_position, e.Oklad
FROM dbo.Employee e
INNER JOIN dbo.Otdel o      ON o.Namber_otdel = e.Namber_otdel
INNER JOIN dbo.[Position] p ON p.Kod_position = e.Kod_position;
GO

SELECT * FROM dbo.SOTR_INFO;

-- 2. Добавить в представление нового сотрудника (указаны только поля одной базовой таблицы).
INSERT dbo.SOTR_INFO (Id_employee, LName, FName, Namber_otdel, Kod_position, Oklad)
VALUES (113, N'Воронов', N'Денис', 1002, 3, 31000);

-- 3. Проверить данные представления и таблицы сотрудников.
SELECT * FROM dbo.SOTR_INFO WHERE Id_employee = 113;
SELECT e.* FROM dbo.Employee e WHERE e.Id_employee = 113;     -- Nadbavka = 0 (значение по умолчанию)

-- 4. Добавить новый отдел.
INSERT dbo.Otdel (Namber_otdel, Name_otdel, Phone)
VALUES (1006, N'Сборочный цех', '843-111-0106');

SELECT * FROM dbo.Otdel;

-- 5. Через представление перевести нового сотрудника в новый отдел.
UPDATE dbo.SOTR_INFO
SET Namber_otdel = 1006
WHERE Id_employee = 113;

-- 6. Проверить данные представления и таблицы сотрудников.
SELECT * FROM dbo.SOTR_INFO WHERE Id_employee = 113;       -- название отдела: «Сборочный цех»
SELECT e.* FROM dbo.Employee e WHERE e.Id_employee = 113;

-- 7. Представление VIPLATA_SOTR: название проекта, количество работающих в нём сотрудников и сумма выплат по проекту.
CREATE VIEW dbo.VIPLATA_SOTR
(Name_Project, Kol_sotr, Summa_vyplat)
AS
SELECT pr.Name_Project, COUNT(DISTINCT pe.Id_employee), SUM(pe.Amount)
FROM dbo.Project pr
INNER JOIN dbo.Project_execution pe ON pe.Namber_Project = pr.Namber_Project
GROUP BY pr.Name_Project;
GO

-- 8. Проверить работу представления VIPLATA_SOTR.
SELECT * FROM dbo.VIPLATA_SOTR ORDER BY Name_Project;

-- 9. Добавить новую запись в таблицу «Исполнение» (новый сотрудник работает в проекте «Бета»).
INSERT dbo.Project_execution (Id_contract, Id_employee, Namber_Project, Quantity_day, Amount)
VALUES (21, 113, 2, 10, 9000);

-- 10. Проверить работу представления VIPLATA_SOTR без его повторного создания.
SELECT * FROM dbo.VIPLATA_SOTR ORDER BY Name_Project;      -- Бета: 4 сотрудника, 54000

-- 11. Представление DOLG_OTDELA: какие разные должности есть в каждом отделе.
CREATE VIEW dbo.DOLG_OTDELA
(Namber_otdel, Name_otdel, Name_position)
AS
SELECT DISTINCT o.Namber_otdel, o.Name_otdel, p.Name_position
FROM dbo.Employee e
INNER JOIN dbo.Otdel o      ON o.Namber_otdel = e.Namber_otdel
INNER JOIN dbo.[Position] p ON p.Kod_position = e.Kod_position;
GO

SELECT * FROM dbo.DOLG_OTDELA ORDER BY Namber_otdel, Name_position;

-- 12. Принять на работу ещё одного сотрудника (программист в производство, где такой должности не было).
INSERT dbo.Employee (Id_employee, FName, LName, Namber_otdel, Kod_position, Oklad, Nadbavka)
VALUES (114, N'Виктор', N'Лебедев', 1003, 5, 37000, 2000);

-- 13. Проверить данные представления DOLG_OTDELA и таблицы сотрудников.
SELECT * FROM dbo.DOLG_OTDELA WHERE Namber_otdel = 1003;     -- добавилась должность «Программист»
SELECT e.* FROM dbo.Employee e WHERE e.Namber_otdel = 1003;

-- 14. Представление KOL_DOLG_OTD на основе DOLG_OTDELA: количество разных должностей в отделе.
CREATE VIEW dbo.KOL_DOLG_OTD
(Namber_otdel, Name_otdel, Kol_dolg)
AS
SELECT d.Namber_otdel, d.Name_otdel, COUNT(d.Name_position)
FROM dbo.DOLG_OTDELA d
GROUP BY d.Namber_otdel, d.Name_otdel;
GO

SELECT * FROM dbo.KOL_DOLG_OTD;

-- 15. Представление Kol_sort_otdela (таблицы и представление KOL_DOLG_OTD): название отдела, количество разных должностей и количество сотрудников.
CREATE VIEW dbo.Kol_sort_otdela
(Name_otdel, Kol_dolg, Kol_sotr)
AS
SELECT o.Name_otdel, ISNULL(k.Kol_dolg, 0), COUNT(e.Id_employee)
FROM dbo.Otdel o
LEFT JOIN dbo.KOL_DOLG_OTD k ON k.Namber_otdel = o.Namber_otdel
LEFT JOIN dbo.Employee e     ON e.Namber_otdel = o.Namber_otdel
GROUP BY o.Name_otdel, k.Kol_dolg;
GO

SELECT * FROM dbo.Kol_sort_otdela;

-- 16. Перевести сотрудника в другой отдел (инженер Назаров из производства в ИТ-отдел).
UPDATE dbo.SOTR_INFO
SET Namber_otdel = 1004
WHERE Id_employee = 107;

-- 17. Проверить работу всех трёх представлений без их повторного запуска.
SELECT * FROM dbo.DOLG_OTDELA   WHERE Namber_otdel IN (1003, 1004) ORDER BY Namber_otdel, Name_position;
SELECT * FROM dbo.KOL_DOLG_OTD  ORDER BY Namber_otdel;
SELECT * FROM dbo.Kol_sort_otdela;

-- 18. Перевести одного сотрудника в другой отдел, оставив ту же должность (менеджер Кузнецова в отдел кадров).
UPDATE dbo.SOTR_INFO
SET Namber_otdel = 1005
WHERE Id_employee = 104;

-- 19. Проверить работу представлений.
SELECT * FROM dbo.DOLG_OTDELA   WHERE Namber_otdel IN (1002, 1005) ORDER BY Namber_otdel, Name_position;
SELECT * FROM dbo.KOL_DOLG_OTD  ORDER BY Namber_otdel;
SELECT * FROM dbo.Kol_sort_otdela;

-- 20. Уволить сотрудника, который не работает ни в одном проекте (сначала найти такого сотрудника).
SELECT e.Id_employee, e.LName
FROM dbo.Employee e
WHERE NOT EXISTS (SELECT 1 FROM dbo.Project_execution pe WHERE pe.Id_employee = e.Id_employee);

-- удаление выполняем в базовой таблице: DELETE через представление с JOIN не поддерживается
DELETE FROM dbo.Employee
WHERE Id_employee = 112;

-- 21. Проверить работу представлений.
SELECT * FROM dbo.SOTR_INFO ORDER BY Namber_otdel, Id_employee;
SELECT * FROM dbo.DOLG_OTDELA ORDER BY Namber_otdel, Name_position;
SELECT * FROM dbo.KOL_DOLG_OTD ORDER BY Namber_otdel;
SELECT * FROM dbo.Kol_sort_otdela;
