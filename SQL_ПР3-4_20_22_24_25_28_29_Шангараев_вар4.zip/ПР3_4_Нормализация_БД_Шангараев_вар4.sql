﻿-- Практические работы № 3 и № 4. Приведение данных к нормальной форме, разработка БД
-- Выполнил: Шангараев Амир Марселевич, группа ИС231-4, вариант 4 (БД «Зарплата сотрудников»)
-- Скрипт создаёт нормализованную БД (3НФ), заполняет её данными из практической работы № 3 и проверяет результат

CREATE DATABASE Zarplata_Norm;
GO
USE Zarplata_Norm;
GO

CREATE TABLE dbo.City (
    CityID     INT           PRIMARY KEY,
    Name_City  NVARCHAR(30)  NOT NULL
);

CREATE TABLE dbo.Street (
    StreetID     INT           PRIMARY KEY,
    Name_Street  NVARCHAR(30)  NOT NULL,
    CityID       INT           NOT NULL REFERENCES dbo.City(CityID)
);

CREATE TABLE dbo.Category (
    CategoryID     INT            PRIMARY KEY,
    Name_Category  NVARCHAR(20)   NOT NULL UNIQUE,
    Oklad          DECIMAL(8,2)   NOT NULL CHECK (Oklad > 0)
);

CREATE TABLE dbo.Employee (
    Tab_Number  INT           PRIMARY KEY,
    Surname     NVARCHAR(30)  NOT NULL,
    StreetID    INT           NOT NULL REFERENCES dbo.Street(StreetID),
    House       NVARCHAR(10)  NOT NULL,
    CategoryID  INT           NOT NULL REFERENCES dbo.Category(CategoryID),
    Kids_Count  INT           NOT NULL DEFAULT 0 CHECK (Kids_Count >= 0)
);

CREATE TABLE dbo.Months (
    Month_Number  INT           PRIMARY KEY,
    Name_Month    NVARCHAR(15)  NOT NULL,
    Work_Days     INT           NOT NULL CHECK (Work_Days BETWEEN 1 AND 31)
);

CREATE TABLE dbo.Salary (
    Id_Zp         INT            PRIMARY KEY,
    Tab_Number    INT            NOT NULL REFERENCES dbo.Employee(Tab_Number),
    Month_Number  INT            NOT NULL REFERENCES dbo.Months(Month_Number),
    Days_Worked   INT            NOT NULL CHECK (Days_Worked >= 0),
    Accrued       DECIMAL(9,2)   NOT NULL,      -- начислено
    Withheld      DECIMAL(9,2)   NOT NULL,      -- удержано
    CONSTRAINT UQ_Salary_Emp_Month UNIQUE (Tab_Number, Month_Number)
);
GO

INSERT dbo.City VALUES (1, N'Казань');

INSERT dbo.Street VALUES (1, N'Галеева', 1), (2, N'Мира', 1), (3, N'Тракт', 1);

INSERT dbo.Category VALUES (1, N'высшая', 25000), (2, N'первая', 20000);

INSERT dbo.Employee (Tab_Number, Surname, StreetID, House, CategoryID, Kids_Count) VALUES
(157, N'Васильева', 1, N'10', 1, 2),
(26,  N'Сахаров',   2, N'16', 2, 0),
(27,  N'Семенова',  3, N'48', 2, 1);

INSERT dbo.Months VALUES (9, N'Сентябрь', 22), (10, N'Октябрь', 21), (11, N'Ноябрь', 22);

INSERT dbo.Salary (Id_Zp, Tab_Number, Month_Number, Days_Worked, Accrued, Withheld) VALUES
(1, 157,  9, 22, 25000, 3000), (2, 157, 10, 19, 23500, 2500), (3, 157, 11, 20, 24000, 2800),
(4, 26,   9, 21, 19000, 5000), (5, 26,  10, 21, 20000, 5500), (6, 26,  11, 19, 17500, 3500),
(7, 27,   9, 21, 19000, 5000), (8, 27,  10, 21, 20000, 5500), (9, 27,  11, 22, 20000, 5500);
GO

-- восстановление исходной таблицы «Заработная плата сотрудников» из нормализованной БД
SELECT e.Tab_Number                              AS [Таб.номер],
       e.Surname                                 AS [Фамилия],
       c.Name_City + N', ул. ' + s.Name_Street + N', ' + e.House AS [Адрес],
       k.Name_Category                           AS [Категория],
       k.Oklad                                   AS [Оклад],
       e.Kids_Count                              AS [Кол.детей],
       m.Name_Month                              AS [Месяц],
       m.Work_Days                               AS [Кол.раб.дней],
       z.Days_Worked                             AS [Кол.отраб.дней],
       z.Accrued                                 AS [Начислено],
       z.Withheld                                AS [Удержано],
       z.Accrued - z.Withheld                    AS [К выдаче]
FROM dbo.Salary z
INNER JOIN dbo.Employee e ON e.Tab_Number   = z.Tab_Number
INNER JOIN dbo.Street   s ON s.StreetID     = e.StreetID
INNER JOIN dbo.City     c ON c.CityID       = s.CityID
INNER JOIN dbo.Category k ON k.CategoryID   = e.CategoryID
INNER JOIN dbo.Months   m ON m.Month_Number = z.Month_Number
ORDER BY e.Tab_Number, m.Month_Number;
