﻿-- Практическая работа № 24. Определение для предметной области объектов, свойств и связей
-- Выполнил: Шангараев Амир Марселевич, группа ИС231-4, вариант 4

-- Создание таблиц с ограничениями
CREATE DATABASE Magazin_Analiz;
GO
USE Magazin_Analiz;
GO

CREATE TABLE dbo.Otdel (
    Namber_otdel  INT           PRIMARY KEY,
    Name_otdel    NVARCHAR(50)  NOT NULL,                        -- ограничение NOT NULL
    Nachalnik     NVARCHAR(50)  NULL
);
CREATE TABLE dbo.Dolzhnost (                                     -- новый объект
    Kod_dolzhnost   INT           PRIMARY KEY,
    Name_dolzhnost  NVARCHAR(40)  NOT NULL
);
CREATE TABLE dbo.Employee (
    Id_employee    INT           PRIMARY KEY,
    LName          NVARCHAR(50)  NOT NULL,
    FName          NVARCHAR(50)  NULL,
    Namber_otdel   INT           NOT NULL REFERENCES dbo.Otdel(Namber_otdel),          -- нельзя удалить отдел с сотрудниками
    Kod_dolzhnost  INT           NULL     REFERENCES dbo.Dolzhnost(Kod_dolzhnost)
);
CREATE TABLE dbo.Product (
    Nomenclature_number  INT            PRIMARY KEY,
    Name_product         NVARCHAR(60)   NOT NULL,                                       -- NOT NULL
    Price_opt            DECIMAL(10,2)  NOT NULL CHECK (Price_opt > 0),                 -- CHECK
    Nacenka              DECIMAL(10,2)  NOT NULL DEFAULT 0 CHECK (Nacenka >= 0),
    Price_rozn           DECIMAL(10,2)  NULL,                                           -- считает триггер
    Namber_otdel         INT            NOT NULL REFERENCES dbo.Otdel(Namber_otdel)
);
CREATE TABLE dbo.Supplier (
    Id_supplier   INT           PRIMARY KEY,
    Name_company  NVARCHAR(60)  NOT NULL,
    Phone         NVARCHAR(20)  NULL UNIQUE                                             -- UNIQUE
);
CREATE TABLE dbo.Invoice (
    Namber_invoice  INT   PRIMARY KEY,
    Invoice_date    DATE  NOT NULL DEFAULT (GETDATE()),                                 -- DEFAULT
    Id_employee_ok  INT   NULL REFERENCES dbo.Employee(Id_employee),
    Id_supplier     INT   NOT NULL REFERENCES dbo.Supplier(Id_supplier)
);
CREATE TABLE dbo.Delivery (
    Id_delivery          INT  PRIMARY KEY,
    Namber_invoice       INT  NOT NULL REFERENCES dbo.Invoice(Namber_invoice) ON DELETE CASCADE,   -- целостность: каскадное удаление
    Nomenclature_number  INT  NOT NULL REFERENCES dbo.Product(Nomenclature_number),
    Quantity             INT  NOT NULL CHECK (Quantity > 0)
);
GO

-- Бизнес-процесс 1: не более 10 сотрудников в отделе
CREATE TRIGGER dbo.trg_Employee_Limit
ON dbo.Employee
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1
               FROM dbo.Employee e
               WHERE e.Namber_otdel IN (SELECT i.Namber_otdel FROM inserted i)
               GROUP BY e.Namber_otdel
               HAVING COUNT(*) > 10)
    BEGIN
        RAISERROR (N'В отделе нет свободных мест. Принять сотрудника нельзя', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

-- Бизнес-процесс 2: автоматический расчёт розничной цены
CREATE TRIGGER dbo.trg_Product_Price
ON dbo.Product
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE p
    SET p.Price_rozn = p.Price_opt + p.Nacenka
    FROM dbo.Product p
    INNER JOIN inserted i ON i.Nomenclature_number = p.Nomenclature_number;
END;
GO

-- Проверка
INSERT dbo.Otdel (Namber_otdel, Name_otdel, Nachalnik) VALUES (1, N'Молочный', N'Иванова');
INSERT dbo.Product (Nomenclature_number, Name_product, Price_opt, Nacenka, Namber_otdel)
VALUES (1, N'Молоко', 60.00, 15.00, 1);
SELECT * FROM dbo.Product;                                  -- Price_rozn = 75.00

-- ошибка CHECK: цена должна быть больше нуля
INSERT dbo.Product (Nomenclature_number, Name_product, Price_opt, Namber_otdel) VALUES (2, N'Кефир', -5, 1);

-- заполняем отдел 10 сотрудниками, 11-й принять нельзя
DECLARE @i INT = 1;
WHILE @i <= 10
BEGIN
    INSERT dbo.Employee (Id_employee, LName, Namber_otdel) VALUES (@i, N'Сотрудник' + CAST(@i AS NVARCHAR(3)), 1);
    SET @i += 1;
END;
INSERT dbo.Employee (Id_employee, LName, Namber_otdel) VALUES (11, N'Лишний', 1);   -- сообщение «нет свободных мест»

-- каскадное удаление строк накладной
INSERT dbo.Supplier VALUES (1, N'ООО Молочный край', N'+7-843-111-11-11');
INSERT dbo.Invoice (Namber_invoice, Id_supplier) VALUES (101, 1);                  -- дата подставится автоматически
INSERT dbo.Delivery VALUES (1, 101, 1, 50);
DELETE FROM dbo.Invoice WHERE Namber_invoice = 101;
SELECT * FROM dbo.Delivery;                                 -- строк нет

-- нельзя удалить отдел, в котором есть сотрудники
DELETE FROM dbo.Otdel WHERE Namber_otdel = 1;               -- ошибка внешнего ключа
