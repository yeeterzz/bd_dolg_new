﻿-- Практическая работа № 22. Итоговые запросы (без вариантов)
-- Выполнил: Шангараев Амир Марселевич, группа ИС231-4, вариант 4
-- База данных: ZAKAZ_IS231_4_Shangaraev

-- Подготовка: создание БД, таблиц и данных
CREATE DATABASE ZAKAZ_IS231_4_Shangaraev;
GO
USE ZAKAZ_IS231_4_Shangaraev;
GO

CREATE TABLE dbo.Otdel (
    Namber_otdel  INT           PRIMARY KEY,
    Name_otdel    NVARCHAR(40)  NULL,
    Phone         CHAR(12)      NULL
);
CREATE TABLE dbo.[Position] (
    Kod_position   INT           PRIMARY KEY,
    Name_position  NVARCHAR(20)  NULL
);
CREATE TABLE dbo.Klient (
    Kod_klient   INT           PRIMARY KEY,
    Name_klient  NVARCHAR(50)  NULL
);
CREATE TABLE dbo.Project (
    Namber_Project  INT            PRIMARY KEY,
    Name_Project    NVARCHAR(50)   NULL,
    Price_Project   DECIMAL(8,0)   NULL,
    Kod_klient      INT            NOT NULL REFERENCES dbo.Klient(Kod_klient),
    Begin_Project   DATE           NULL,
    End_Project     DATE           NULL
);
CREATE TABLE dbo.Employee (
    Id_employee   INT            PRIMARY KEY,
    FName         NVARCHAR(20)   NULL,          -- имя
    LName         NVARCHAR(50)   NULL,          -- фамилия
    Namber_otdel  INT            NOT NULL REFERENCES dbo.Otdel(Namber_otdel),
    Kod_position  INT            NOT NULL REFERENCES dbo.[Position](Kod_position),
    Oklad         DECIMAL(7,2)   NOT NULL,
    Nadbavka      DECIMAL(6,2)   NOT NULL DEFAULT 0
);
CREATE TABLE dbo.Project_execution (
    Id_contract    INT            PRIMARY KEY,
    Id_employee    INT            NOT NULL REFERENCES dbo.Employee(Id_employee),
    Namber_Project INT            NOT NULL REFERENCES dbo.Project(Namber_Project),
    Quantity_day   INT            NULL,
    Amount         DECIMAL(7,2)   NULL
);
GO

INSERT dbo.Otdel VALUES
(1001, N'Бухгалтерия',  '843-111-0101'), (1002, N'Отдел продаж', '843-111-0102'),
(1003, N'Производство', '843-111-0103'), (1004, N'ИТ-отдел',     '843-111-0104'),
(1005, N'Отдел кадров', '843-111-0105');

INSERT dbo.[Position] VALUES (1, N'Начальник'), (2, N'Бухгалтер'), (3, N'Менеджер'),
                             (4, N'Инженер'), (5, N'Программист'), (6, N'Рабочий');

INSERT dbo.Klient VALUES (1, N'ООО Заря'), (2, N'АО Холод'), (3, N'ЗАО Таттелеком'),
                         (4, N'ООО Геракл'), (5, N'ИП Фёдоров');

INSERT dbo.Project VALUES
(1, N'Альфа',  1200000, 1, '2025-01-10', '2025-06-30'),
(2, N'Бета',    850000, 2, '2025-02-01', '2025-07-15'),
(3, N'Гамма',  2100000, 3, '2025-03-15', '2025-12-20'),
(4, N'Дельта',  640000, 1, '2025-05-01', '2025-09-30'),
(5, N'Омега',  1500000, 4, '2025-06-01', '2026-02-28');

INSERT dbo.Employee (Id_employee, FName, LName, Namber_otdel, Kod_position, Oklad, Nadbavka) VALUES
(101, N'Пётр',   N'Иванов',     1001, 1, 45000, 8000),
(102, N'Анна',   N'Петрова',    1001, 2, 38000, 5000),
(103, N'Олег',   N'Сидоров',    1002, 1, 42000, 7000),
(104, N'Мария',  N'Кузнецова',  1002, 3, 30000, 4000),
(105, N'Игорь',  N'Смирнов',    1003, 1, 40000, 6000),
(106, N'Лейла',  N'Галимова',   1003, 6, 28000, 2000),
(107, N'Ильдар', N'Назаров',    1003, 4, 36000, 3500),
(108, N'Рустам', N'Ахмадуллин', 1004, 1, 47000, 9000),
(109, N'Елена',  N'Орлова',     1004, 5, 41000, 4500),
(110, N'Игорь',  N'Сахаров',    1004, 5, 39000, 3000),
(111, N'Алина',  N'Зайцева',    1005, 3, 29000, 1500),
(112, N'Артём',  N'Волков',     1005, 2, 33000, 2500);

INSERT dbo.Project_execution (Id_contract, Id_employee, Namber_Project, Quantity_day, Amount) VALUES
(1, 101, 1, 20, 15000), (2, 102, 1, 15, 10000), (3, 104, 1, 10,  8000), (4, 107, 1, 25, 18000),
(5, 103, 2, 18, 14000), (6, 104, 2, 12,  9000), (7, 109, 2, 30, 22000),
(8, 105, 3, 40, 30000), (9, 106, 3, 35, 20000), (10, 107, 3, 28, 21000), (11, 108, 3, 22, 19000), (12, 109, 3, 25, 18500),
(13, 101, 4, 10,  7500), (14, 108, 4, 20, 16000), (15, 110, 4, 32, 23000),
(16, 103, 5, 14, 11000), (17, 105, 5, 16, 12500), (18, 109, 5, 18, 13500), (19, 110, 5, 24, 17500), (20, 106, 5, 12, 6000);
GO

-- 1. Отчёт по заработной плате в разрезе кодов должностей по номеру каждого отдела с итогом по каждому отделу (ROLLUP).
SELECT ISNULL(CAST(e.Namber_otdel AS NVARCHAR(20)), N'ВСЕГО') AS [№ отдела],
       ISNULL(CAST(e.Kod_position AS NVARCHAR(20)), N'Итого по отделу') AS [Код должности],
       SUM(e.Oklad + e.Nadbavka) AS [Заработная плата]
FROM dbo.Employee e
GROUP BY ROLLUP (e.Namber_otdel, e.Kod_position);

-- 2. Отчёт по заработной плате в разрезе названий должностей по названию каждого отдела с итогом по отделу (ROLLUP и GROUPING).
SELECT CASE WHEN GROUPING(o.Name_otdel) = 1 THEN N'ОБЩИЙ ИТОГ' ELSE o.Name_otdel END AS [Отдел],
       CASE WHEN GROUPING(p.Name_position) = 1 AND GROUPING(o.Name_otdel) = 0 THEN N'Итого по отделу'
            WHEN GROUPING(p.Name_position) = 1 THEN N''
            ELSE p.Name_position END AS [Должность],
       SUM(e.Oklad + e.Nadbavka) AS [Заработная плата]
FROM dbo.Employee e
INNER JOIN dbo.Otdel o      ON o.Namber_otdel = e.Namber_otdel
INNER JOIN dbo.[Position] p ON p.Kod_position = e.Kod_position
GROUP BY ROLLUP (o.Name_otdel, p.Name_position)
ORDER BY GROUPING(o.Name_otdel), o.Name_otdel, GROUPING(p.Name_position), p.Name_position;

-- 3. Отчёт по заработной плате в разрезе номеров подразделений по каждой должности с итогом по должности (ROLLUP и GROUPING).
SELECT CASE WHEN GROUPING(p.Name_position) = 1 THEN N'ОБЩИЙ ИТОГ' ELSE p.Name_position END AS [Должность],
       CASE WHEN GROUPING(e.Namber_otdel) = 1 AND GROUPING(p.Name_position) = 0 THEN N'Итого по должности'
            WHEN GROUPING(e.Namber_otdel) = 1 THEN N''
            ELSE CAST(e.Namber_otdel AS NVARCHAR(10)) END AS [№ отдела],
       SUM(e.Oklad + e.Nadbavka) AS [Заработная плата]
FROM dbo.Employee e
INNER JOIN dbo.[Position] p ON p.Kod_position = e.Kod_position
GROUP BY ROLLUP (p.Name_position, e.Namber_otdel)
ORDER BY GROUPING(p.Name_position), p.Name_position, GROUPING(e.Namber_otdel), e.Namber_otdel;

-- 4. Отчёт по заработной плате в разрезе названий должностей и названий отделов со всеми перекрёстными вычислениями (CUBE).
SELECT CASE WHEN GROUPING(p.Name_position) = 1 THEN N'Все должности' ELSE p.Name_position END AS [Должность],
       CASE WHEN GROUPING(o.Name_otdel) = 1 THEN N'Все отделы' ELSE o.Name_otdel END AS [Отдел],
       SUM(e.Oklad + e.Nadbavka) AS [Заработная плата]
FROM dbo.Employee e
INNER JOIN dbo.Otdel o      ON o.Namber_otdel = e.Namber_otdel
INNER JOIN dbo.[Position] p ON p.Kod_position = e.Kod_position
GROUP BY CUBE (p.Name_position, o.Name_otdel)
ORDER BY GROUPING(p.Name_position), p.Name_position, GROUPING(o.Name_otdel), o.Name_otdel;

-- 5. Заработная плата по каждому отделу с общим итогом (ROLLUP по одному полю).
SELECT ISNULL(o.Name_otdel, N'ВСЕГО') AS [Отдел], SUM(e.Oklad + e.Nadbavka) AS [Заработная плата]
FROM dbo.Employee e
INNER JOIN dbo.Otdel o ON o.Namber_otdel = e.Namber_otdel
GROUP BY ROLLUP (o.Name_otdel);

-- 6. Имена клиентов со стоимостью их проектов и общим итогом всех проектов.
SELECT CASE WHEN GROUPING(k.Name_klient) = 1 THEN N'ОБЩИЙ ИТОГ' ELSE k.Name_klient END AS [Клиент],
       CASE WHEN GROUPING(pr.Name_Project) = 1 AND GROUPING(k.Name_klient) = 0 THEN N'Итого по клиенту'
            WHEN GROUPING(pr.Name_Project) = 1 THEN N''
            ELSE pr.Name_Project END AS [Проект],
       SUM(pr.Price_Project) AS [Стоимость проектов]
FROM dbo.Klient k
INNER JOIN dbo.Project pr ON pr.Kod_klient = k.Kod_klient
GROUP BY ROLLUP (k.Name_klient, pr.Name_Project)
ORDER BY GROUPING(k.Name_klient), k.Name_klient, GROUPING(pr.Name_Project), pr.Name_Project;

-- 7. Отчёт по проектам и сотрудникам: выплаченные суммы и отработанные дни по каждому проекту, по каждому сотруднику и всего (CUBE по номерам).
SELECT pe.Namber_Project AS [№ проекта],
       pe.Id_employee    AS [Таб. №],
       SUM(pe.Amount)       AS [Выплачено],
       SUM(pe.Quantity_day) AS [Отработано дней]
FROM dbo.Project_execution pe
GROUP BY CUBE (pe.Namber_Project, pe.Id_employee)
ORDER BY GROUPING(pe.Namber_Project), pe.Namber_Project, GROUPING(pe.Id_employee), pe.Id_employee;

-- 8.1. Тот же отчёт с фамилиями сотрудников и названиями проектов (UNION ALL).
SELECT x.[Проект], x.[Сотрудник], x.[Выплачено], x.[Отработано дней]
FROM (
    SELECT pr.Name_Project AS [Проект], e.LName AS [Сотрудник],
           SUM(pe.Amount) AS [Выплачено], SUM(pe.Quantity_day) AS [Отработано дней], 0 AS Grp, 0 AS Sub
    FROM dbo.Project_execution pe
    INNER JOIN dbo.Employee e ON e.Id_employee = pe.Id_employee
    INNER JOIN dbo.Project pr ON pr.Namber_Project = pe.Namber_Project
    GROUP BY pr.Name_Project, e.LName
    UNION ALL
    SELECT pr.Name_Project, N'Итого по проекту', SUM(pe.Amount), SUM(pe.Quantity_day), 0, 1
    FROM dbo.Project_execution pe
    INNER JOIN dbo.Project pr ON pr.Namber_Project = pe.Namber_Project
    GROUP BY pr.Name_Project
    UNION ALL
    SELECT N'Итого по сотруднику', e.LName, SUM(pe.Amount), SUM(pe.Quantity_day), 1, 0
    FROM dbo.Project_execution pe
    INNER JOIN dbo.Employee e ON e.Id_employee = pe.Id_employee
    GROUP BY e.LName
    UNION ALL
    SELECT N'ВСЕГО', N'', SUM(pe.Amount), SUM(pe.Quantity_day), 2, 0
    FROM dbo.Project_execution pe
) x
ORDER BY x.Grp, x.[Проект], x.Sub, x.[Сотрудник];

-- 8.2. Тот же отчёт с помощью GROUPING SETS.
SELECT CASE WHEN GROUPING(pr.Name_Project) = 1 AND GROUPING(e.LName) = 1 THEN N'ВСЕГО'
            WHEN GROUPING(pr.Name_Project) = 1 THEN N'Итого по сотруднику'
            ELSE pr.Name_Project END AS [Проект],
       CASE WHEN GROUPING(e.LName) = 1 AND GROUPING(pr.Name_Project) = 0 THEN N'Итого по проекту'
            WHEN GROUPING(e.LName) = 1 THEN N''
            ELSE e.LName END AS [Сотрудник],
       SUM(pe.Amount)       AS [Выплачено],
       SUM(pe.Quantity_day) AS [Отработано дней]
FROM dbo.Project_execution pe
INNER JOIN dbo.Employee e ON e.Id_employee = pe.Id_employee
INNER JOIN dbo.Project pr ON pr.Namber_Project = pe.Namber_Project
GROUP BY GROUPING SETS ((pr.Name_Project, e.LName), (pr.Name_Project), (e.LName), ())
ORDER BY GROUPING(pr.Name_Project), pr.Name_Project, GROUPING(e.LName), e.LName;

-- 9. Отчёт «Сотрудники — Проекты» с итогом выплат по сотрудникам и по проектам (PIVOT).
SELECT ISNULL(pv.LName, N'ИТОГО выплаты по проектам') AS [Сотрудники],
       SUM(pv.[Альфа])  AS [Альфа],
       SUM(pv.[Бета])   AS [Бета],
       SUM(pv.[Гамма])  AS [Гамма],
       SUM(pv.[Дельта]) AS [Дельта],
       SUM(pv.[Омега])  AS [Омега],
       SUM(ISNULL(pv.[Альфа], 0) + ISNULL(pv.[Бета], 0) + ISNULL(pv.[Гамма], 0)
         + ISNULL(pv.[Дельта], 0) + ISNULL(pv.[Омега], 0)) AS [Итого выплаты по сотрудникам]
FROM (
    SELECT e.LName, pr.Name_Project, pe.Amount
    FROM dbo.Project_execution pe
    INNER JOIN dbo.Employee e ON e.Id_employee = pe.Id_employee
    INNER JOIN dbo.Project pr ON pr.Namber_Project = pe.Namber_Project
) src
PIVOT (SUM(src.Amount) FOR src.Name_Project IN ([Альфа], [Бета], [Гамма], [Дельта], [Омега])) pv
GROUP BY ROLLUP (pv.LName)
ORDER BY GROUPING(pv.LName), pv.LName;

-- 10. Отчёт «Должности — Отделы» с ФОТ по должностям и по отделам (PIVOT).
SELECT ISNULL(pv.Name_position, N'ФОТ по отделам') AS [Должности],
       SUM(pv.[Бухгалтерия])  AS [Бухгалтерия],
       SUM(pv.[Отдел продаж]) AS [Отдел продаж],
       SUM(pv.[Производство]) AS [Производство],
       SUM(pv.[ИТ-отдел])     AS [ИТ-отдел],
       SUM(pv.[Отдел кадров]) AS [Отдел кадров],
       SUM(ISNULL(pv.[Бухгалтерия], 0) + ISNULL(pv.[Отдел продаж], 0) + ISNULL(pv.[Производство], 0)
         + ISNULL(pv.[ИТ-отдел], 0) + ISNULL(pv.[Отдел кадров], 0)) AS [ФОТ по должностям]
FROM (
    SELECT p.Name_position, o.Name_otdel, e.Oklad + e.Nadbavka AS Zp
    FROM dbo.Employee e
    INNER JOIN dbo.Otdel o      ON o.Namber_otdel = e.Namber_otdel
    INNER JOIN dbo.[Position] p ON p.Kod_position = e.Kod_position
) src
PIVOT (SUM(src.Zp) FOR src.Name_otdel IN ([Бухгалтерия], [Отдел продаж], [Производство], [ИТ-отдел], [Отдел кадров])) pv
GROUP BY ROLLUP (pv.Name_position)
ORDER BY GROUPING(pv.Name_position), pv.Name_position;
