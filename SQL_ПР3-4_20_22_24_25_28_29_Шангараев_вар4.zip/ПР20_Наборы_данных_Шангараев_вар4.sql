﻿-- Практическая работа № 20. Запросы для работы с наборами данных (без вариантов)
-- Выполнил: Шангараев Амир Марселевич, группа ИС231-4, вариант 4
-- База данных: ZAKAZ

-- Подготовка: создание БД, таблиц и данных
CREATE DATABASE ZAKAZ;
GO
USE ZAKAZ;
GO

CREATE TABLE dbo.Otdel (
    Namber_otdel  INT           PRIMARY KEY,
    Name_otdel    NVARCHAR(40)  NULL,
    Phone         CHAR(12)      NULL
);
CREATE TABLE dbo.[Position] (
    Kod_position   INT           PRIMARY KEY,
    Name_position  NVARCHAR(20)  NULL
);
CREATE TABLE dbo.Klient (
    Kod_klient   INT           PRIMARY KEY,
    Name_klient  NVARCHAR(50)  NULL
);
CREATE TABLE dbo.Project (
    Namber_Project  INT            PRIMARY KEY,
    Name_Project    NVARCHAR(50)   NULL,
    Price_Project   DECIMAL(8,0)   NULL,
    Kod_klient      INT            NOT NULL REFERENCES dbo.Klient(Kod_klient),
    Begin_Project   DATE           NULL,
    End_Project     DATE           NULL
);
CREATE TABLE dbo.Employee (
    Id_employee   INT            PRIMARY KEY,
    FName         NVARCHAR(20)   NULL,          -- имя
    LName         NVARCHAR(50)   NULL,          -- фамилия
    Namber_otdel  INT            NOT NULL REFERENCES dbo.Otdel(Namber_otdel),
    Kod_position  INT            NOT NULL REFERENCES dbo.[Position](Kod_position),
    Oklad         DECIMAL(7,2)   NOT NULL,
    Nadbavka      DECIMAL(6,2)   NOT NULL DEFAULT 0
);
CREATE TABLE dbo.Project_execution (
    Id_contract    INT            PRIMARY KEY,
    Id_employee    INT            NOT NULL REFERENCES dbo.Employee(Id_employee),
    Namber_Project INT            NOT NULL REFERENCES dbo.Project(Namber_Project),
    Quantity_day   INT            NULL,
    Amount         DECIMAL(7,2)   NULL
);
GO

INSERT dbo.Otdel VALUES
(1001, N'Бухгалтерия',  '843-111-0101'), (1002, N'Отдел продаж', '843-111-0102'),
(1003, N'Производство', '843-111-0103'), (1004, N'ИТ-отдел',     '843-111-0104'),
(1005, N'Отдел кадров', '843-111-0105');

INSERT dbo.[Position] VALUES (1, N'Начальник'), (2, N'Бухгалтер'), (3, N'Менеджер'),
                             (4, N'Инженер'), (5, N'Программист'), (6, N'Рабочий');

INSERT dbo.Klient VALUES (1, N'ООО Заря'), (2, N'АО Холод'), (3, N'ЗАО Таттелеком'),
                         (4, N'ООО Геракл'), (5, N'ИП Фёдоров');

INSERT dbo.Project VALUES
(1, N'Альфа',  1200000, 1, '2025-01-10', '2025-06-30'),
(2, N'Бета',    850000, 2, '2025-02-01', '2025-07-15'),
(3, N'Гамма',  2100000, 3, '2025-03-15', '2025-12-20'),
(4, N'Дельта',  640000, 1, '2025-05-01', '2025-09-30'),
(5, N'Омега',  1500000, 4, '2025-06-01', '2026-02-28');

INSERT dbo.Employee (Id_employee, FName, LName, Namber_otdel, Kod_position, Oklad, Nadbavka) VALUES
(101, N'Пётр',   N'Иванов',     1001, 1, 45000, 8000),
(102, N'Анна',   N'Петрова',    1001, 2, 38000, 5000),
(103, N'Олег',   N'Сидоров',    1002, 1, 42000, 7000),
(104, N'Мария',  N'Кузнецова',  1002, 3, 30000, 4000),
(105, N'Игорь',  N'Смирнов',    1003, 1, 40000, 6000),
(106, N'Лейла',  N'Галимова',   1003, 6, 28000, 2000),
(107, N'Ильдар', N'Назаров',    1003, 4, 36000, 3500),
(108, N'Рустам', N'Ахмадуллин', 1004, 1, 47000, 9000),
(109, N'Елена',  N'Орлова',     1004, 5, 41000, 4500),
(110, N'Игорь',  N'Сахаров',    1004, 5, 39000, 3000),
(111, N'Алина',  N'Зайцева',    1005, 3, 29000, 1500),
(112, N'Артём',  N'Волков',     1005, 2, 33000, 2500);

INSERT dbo.Project_execution (Id_contract, Id_employee, Namber_Project, Quantity_day, Amount) VALUES
(1, 101, 1, 20, 15000), (2, 102, 1, 15, 10000), (3, 104, 1, 10,  8000), (4, 107, 1, 25, 18000),
(5, 103, 2, 18, 14000), (6, 104, 2, 12,  9000), (7, 109, 2, 30, 22000),
(8, 105, 3, 40, 30000), (9, 106, 3, 35, 20000), (10, 107, 3, 28, 21000), (11, 108, 3, 22, 19000), (12, 109, 3, 25, 18500),
(13, 101, 4, 10,  7500), (14, 108, 4, 20, 16000), (15, 110, 4, 32, 23000),
(16, 103, 5, 14, 11000), (17, 105, 5, 16, 12500), (18, 109, 5, 18, 13500), (19, 110, 5, 24, 17500), (20, 106, 5, 12, 6000);
GO

-- 1. Подготовка данных: заполнить таблицу Klient данными из таблицы Employee (четыре сотрудника становятся клиентами).
INSERT dbo.Klient (Kod_klient, Name_klient)
SELECT e.Id_employee, e.LName
FROM dbo.Employee e
WHERE e.Id_employee IN (102, 104, 107, 109);

SELECT * FROM dbo.Klient;

-- 2. Определить или сотрудников, или клиентов, или и тех и других (UNION).
SELECT e.Id_employee AS [Код], e.LName AS [Имя]
FROM dbo.Employee e
UNION
SELECT k.Kod_klient, k.Name_klient
FROM dbo.Klient k
ORDER BY [Код];

-- 3. То же без уникальности строк (UNION ALL).
SELECT e.Id_employee AS [Код], e.LName AS [Имя]
FROM dbo.Employee e
UNION ALL
SELECT k.Kod_klient, k.Name_klient
FROM dbo.Klient k
ORDER BY [Код];

-- 3а. Определить, кто является и сотрудником, и клиентом одновременно (INTERSECT).
SELECT e.Id_employee AS [Код], e.LName AS [Имя]
FROM dbo.Employee e
INTERSECT
SELECT k.Kod_klient, k.Name_klient
FROM dbo.Klient k
ORDER BY [Код];

-- 4. Определить только тех, кто является сотрудником (EXCEPT).
SELECT e.Id_employee AS [Код], e.LName AS [Только сотрудники]
FROM dbo.Employee e
EXCEPT
SELECT k.Kod_klient, k.Name_klient
FROM dbo.Klient k
ORDER BY [Код];

-- 5. Определить только тех, кто является клиентом (EXCEPT).
SELECT k.Kod_klient AS [Код], k.Name_klient AS [Только клиенты]
FROM dbo.Klient k
EXCEPT
SELECT e.Id_employee, e.LName
FROM dbo.Employee e
ORDER BY [Код];

-- 6. Определить только тех, кто является или сотрудником, или клиентом (но не обоими сразу).
(SELECT e.Id_employee AS [Код], e.LName AS [Имя]
 FROM dbo.Employee e
 EXCEPT
 SELECT k.Kod_klient, k.Name_klient
 FROM dbo.Klient k)
UNION
(SELECT k.Kod_klient, k.Name_klient
 FROM dbo.Klient k
 EXCEPT
 SELECT e.Id_employee, e.LName
 FROM dbo.Employee e)
ORDER BY [Код];

-- 7. То же с учётом отдела и заработной платы (заработная плата = оклад + надбавка). Для клиентов, не являющихся сотрудниками, отдел «НЕТ отдела», зарплата 0.
(SELECT e.LName AS [Имя], o.Name_otdel AS [Отдел], e.Oklad + e.Nadbavka AS [Заработная плата]
 FROM dbo.Employee e
 INNER JOIN dbo.Otdel o ON o.Namber_otdel = e.Namber_otdel
 EXCEPT
 SELECT k.Name_klient, ISNULL(o.Name_otdel, N'НЕТ отдела'), ISNULL(e.Oklad + e.Nadbavka, 0)
 FROM dbo.Klient k
 LEFT JOIN dbo.Employee e ON e.Id_employee = k.Kod_klient
 LEFT JOIN dbo.Otdel o    ON o.Namber_otdel = e.Namber_otdel)
UNION
(SELECT k.Name_klient, ISNULL(o.Name_otdel, N'НЕТ отдела'), ISNULL(e.Oklad + e.Nadbavka, 0)
 FROM dbo.Klient k
 LEFT JOIN dbo.Employee e ON e.Id_employee = k.Kod_klient
 LEFT JOIN dbo.Otdel o    ON o.Namber_otdel = e.Namber_otdel
 EXCEPT
 SELECT e.LName, o.Name_otdel, e.Oklad + e.Nadbavka
 FROM dbo.Employee e
 INNER JOIN dbo.Otdel o ON o.Namber_otdel = e.Namber_otdel)
ORDER BY [Отдел], [Имя];

-- 8. Подготовка к запросу 10: найти сумму всех выплат сотрудникам по проектам.
SELECT pr.Name_Project AS [Проект], SUM(pe.Amount) AS [Сумма выплат по проекту]
FROM dbo.Project_execution pe
INNER JOIN dbo.Project pr ON pr.Namber_Project = pe.Namber_Project
GROUP BY pr.Name_Project
ORDER BY pr.Name_Project;

-- 9. Продолжение подготовки: найти сумму выплат каждому сотруднику по всем проектам, в которых он участвует.
SELECT e.LName AS [Сотрудник], SUM(pe.Amount) AS [Сумма выплат по всем проектам]
FROM dbo.Project_execution pe
INNER JOIN dbo.Employee e ON e.Id_employee = pe.Id_employee
GROUP BY e.LName
ORDER BY e.LName;

-- 10. Вывести выплату каждого сотрудника по каждому проекту, сумму выплат каждому сотруднику и итого выплат по всем проектам (UNION ALL).
SELECT x.[Сотрудник], x.[Проект], x.[Выплата]
FROM (
    SELECT e.LName AS [Сотрудник], pr.Name_Project AS [Проект], pe.Amount AS [Выплата],
           e.LName AS Ord1, 0 AS Ord2
    FROM dbo.Project_execution pe
    INNER JOIN dbo.Employee e ON e.Id_employee = pe.Id_employee
    INNER JOIN dbo.Project pr ON pr.Namber_Project = pe.Namber_Project
    UNION ALL
    SELECT e.LName, N'Итого по сотруднику', SUM(pe.Amount), e.LName, 1
    FROM dbo.Project_execution pe
    INNER JOIN dbo.Employee e ON e.Id_employee = pe.Id_employee
    GROUP BY e.LName
    UNION ALL
    SELECT N'ВСЕГО', N'Итого по всем проектам', SUM(pe.Amount), N'яяяя', 2
    FROM dbo.Project_execution pe
) x
ORDER BY x.Ord1, x.Ord2, x.[Проект];
